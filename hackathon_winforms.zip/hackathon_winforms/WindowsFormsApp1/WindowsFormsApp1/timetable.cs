﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;


namespace WindowsFormsApp1
{
    public partial class timetable : Form
    {
        Thread th;
        public timetable()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
            btnTimeTable.BackColor = Color.DimGray;
        }

        private void btnTimeTable_Click(object sender, EventArgs e)
        {
           // timetable tt = new timetable();
           // tt.Show();

            this.Close();
            th = new Thread(openNewTimeTable);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void btnCourse_Click(object sender, EventArgs e)
        {
            //courses course = new courses();
            //course.Show();

            this.Close();
            th = new Thread(opennewform);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void btnTeams_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", "https://www.microsoft.com/en-au/microsoft-teams/log-in");
        }

        private void btnOutlook_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", "https://outlook.office365.com/mail/login.html");
        }


        public void opennewform(object obj)
        {
            Application.Run(new courses());
        }

        public void openNewTimeTable(object obj)
        {
            Application.Run(new timetable());
        }
    }
}
