﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        Thread th;
        public Form1()
        {
            InitializeComponent();
            WindowState = FormWindowState.Maximized;
        }

        private void ttbtn_Click(object sender, EventArgs e)
        {
            //openNewTimeTable
            //timetable tt = new timetable();
            //tt.Show();

            this.Close();
            th = new Thread(openNewTimeTable);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
        }

        private void btnCoures_Click(object sender, EventArgs e)
        {
            this.Close();
            th = new Thread(opennewform);
            th.SetApartmentState(ApartmentState.STA);
            th.Start();
            // courses course = new courses();
            //course.Show();
        }

        private void btnTeams_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", "https://www.microsoft.com/en-au/microsoft-teams/log-in");
        }

        private void btnOutlook_Click(object sender, EventArgs e)
        {
            Process.Start("chrome.exe", "https://outlook.office365.com/mail/login.html");
        }


        public void opennewform(object obj)
        {
            Application.Run(new courses());
        }

        public void openNewTimeTable(object obj)
        {
            Application.Run(new timetable());
        }
    }
}
